string="This is a string"
print(string)
print(type(string))
print(str(string)+ "is of the form"+ str(type(string)))
firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)
name = input("What is your name? ")
print(name)
color = input("What is your favorite color?  ")
animal = input("What is your favorite animal?  ")
print("{} ,do you like {}  {}!".format(name,color,animal))
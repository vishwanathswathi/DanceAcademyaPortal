print("Python has three numeric types: int, float, and complex")
# a=eval(input("enter the A value:"))
# b=eval(input("enter the B value:"))
# if(a>b):
#     print("A is greater than B");
# else:
#     print("B is greater than A:")
# num=eval(input("enter the number:"))
# if(num%2)==0:
#     print("no is even")
# else:
#     print("no is odd")
# print(num)
value="swathi"
value=3
print(value)
print(str(value) + "is of the data type" +str(type(value)))
value=3.3
print(value)
print(str(value) + "is of the data type" +str(type(value)))
value1=5j
print(value1)
print(type(value1))
print(str(value1)+ "  is of the data type "+ str(type(value1)))
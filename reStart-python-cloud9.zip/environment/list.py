myFruitList = ["apple", "banana", "cherry"]
print(myFruitList)
print(type(myFruitList))
tup=('red','blue','green','gray')
print(tup)
print(type(tup))
print(tup[0])
print(tup[1])
print(tup[3])
dict1={
    'name':'swathi',
    'education':'B.Tech',
    'branch':'CSE'
}
print(dict1)
print(type(dict1))
print(dict1['name'])
print(dict1['branch'])